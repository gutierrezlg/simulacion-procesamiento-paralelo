Ejemplo 2: Conteo de números primos

Este código compara:
- procesamiento secuencial
- procesamiento paralelo

Idea:
Se analiza un rango grande de números y se cuenta cuántos son primos.
Este ejemplo suele favorecer más el paralelismo porque cada número requiere
más cálculo que una simple validación de paridad.

Uso en Google Colab:
1. Crear un notebook nuevo.
2. Subir este archivo .py o copiar el contenido en una celda.
3. Ejecutar el código.
