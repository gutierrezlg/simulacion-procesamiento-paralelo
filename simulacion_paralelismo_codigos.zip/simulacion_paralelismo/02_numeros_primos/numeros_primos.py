import time
import math
import multiprocessing as mp

# ---------------------------
# FUNCIONES
# ---------------------------
def es_primo(n):
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False

    limite = int(math.sqrt(n)) + 1
    for i in range(3, limite, 2):
        if n % i == 0:
            return False
    return True

def contar_primos_secuencial(inicio, fin):
    contador = 0
    for n in range(inicio, fin):
        if es_primo(n):
            contador += 1
    return contador

def contar_primos_rango(rango):
    inicio, fin = rango
    contador = 0
    for n in range(inicio, fin):
        if es_primo(n):
            contador += 1
    return contador

def dividir_rangos(inicio, fin, partes):
    tam = (fin - inicio) // partes
    rangos = []
    actual = inicio

    for i in range(partes):
        siguiente = actual + tam
        if i == partes - 1:
            siguiente = fin
        rangos.append((actual, siguiente))
        actual = siguiente

    return rangos

# ---------------------------
# PROGRAMA PRINCIPAL
# ---------------------------
if __name__ == "__main__":
    inicio_rango = 1
    fin_rango = 300_000   # si quieres más diferencia, prueba 500_000 o 800_000

    # --- Secuencial ---
    inicio_sec = time.time()
    resultado_sec = contar_primos_secuencial(inicio_rango, fin_rango)
    fin_sec = time.time()

    tiempo_sec = fin_sec - inicio_sec

    # --- Paralelo ---
    nucleos = mp.cpu_count()
    rangos = dividir_rangos(inicio_rango, fin_rango, nucleos)

    inicio_par = time.time()
    with mp.Pool(processes=nucleos) as pool:
        resultados = pool.map(contar_primos_rango, rangos)
    resultado_par = sum(resultados)
    fin_par = time.time()

    tiempo_par = fin_par - inicio_par

    # --- Resultados ---
    print("===== EJEMPLO 2: NÚMEROS PRIMOS =====")
    print(f"Núcleos detectados: {nucleos}")
    print(f"Primos encontrados (secuencial): {resultado_sec}")
    print(f"Tiempo secuencial: {tiempo_sec:.4f} segundos")
    print()
    print(f"Primos encontrados (paralelo): {resultado_par}")
    print(f"Tiempo paralelo: {tiempo_par:.4f} segundos")
    print()

    if tiempo_par > 0:
        print(f"Speedup: {tiempo_sec / tiempo_par:.4f}x")
