Ejemplo 1: Conteo de números pares

Este código compara:
- procesamiento secuencial
- procesamiento paralelo

Idea:
Se recorre una lista grande de números y se cuenta cuántos son pares.
Este ejemplo suele mostrar que una tarea muy simple puede no beneficiarse del paralelismo,
debido al costo de dividir el trabajo y coordinar procesos.

Uso en Google Colab:
1. Crear un notebook nuevo.
2. Subir este archivo .py o copiar el contenido en una celda.
3. Ejecutar el código.
