import time
import multiprocessing as mp
from math import ceil

# ---------------------------
# FUNCIONES
# ---------------------------
def contar_pares_secuencial(datos):
    contador = 0
    for n in datos:
        if n % 2 == 0:
            contador += 1
    return contador

def contar_pares_bloque(bloque):
    contador = 0
    for n in bloque:
        if n % 2 == 0:
            contador += 1
    return contador

def dividir_en_bloques(lista, num_bloques):
    tam_bloque = ceil(len(lista) / num_bloques)
    return [lista[i:i + tam_bloque] for i in range(0, len(lista), tam_bloque)]

# ---------------------------
# PROGRAMA PRINCIPAL
# ---------------------------
if __name__ == "__main__":
    # Lista grande, pero operación muy simple
    datos = list(range(1, 5_000_000))

    # --- Secuencial ---
    inicio_sec = time.time()
    resultado_sec = contar_pares_secuencial(datos)
    fin_sec = time.time()

    tiempo_sec = fin_sec - inicio_sec

    # --- Paralelo ---
    nucleos = mp.cpu_count()
    bloques = dividir_en_bloques(datos, nucleos)

    inicio_par = time.time()
    with mp.Pool(processes=nucleos) as pool:
        resultados = pool.map(contar_pares_bloque, bloques)
    resultado_par = sum(resultados)
    fin_par = time.time()

    tiempo_par = fin_par - inicio_par

    # --- Resultados ---
    print("===== EJEMPLO 1: CONTAR PARES =====")
    print(f"Núcleos detectados: {nucleos}")
    print(f"Resultado secuencial: {resultado_sec}")
    print(f"Tiempo secuencial: {tiempo_sec:.4f} segundos")
    print()
    print(f"Resultado paralelo: {resultado_par}")
    print(f"Tiempo paralelo: {tiempo_par:.4f} segundos")
    print()

    if tiempo_par > 0:
        print(f"Speedup: {tiempo_sec / tiempo_par:.4f}x")
