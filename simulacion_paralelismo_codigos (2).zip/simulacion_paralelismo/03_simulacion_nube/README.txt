Ejemplo 3: Simulación de procesamiento en la nube

Este código representa de forma sencilla cómo una plataforma cloud
distribuye datos entre varios nodos o workers.

Idea:
- Se simulan millones de transacciones.
- El sistema revisa cuáles superan un umbral.
- En modo secuencial, un solo proceso revisa todo.
- En modo distribuido, varios nodos procesan bloques al mismo tiempo.

Qué representa:
- nodo cloud = recurso de cómputo
- bloque de datos = partición de información
- resultado parcial = salida de cada nodo
- suma final = consolidación central

Uso en Google Colab:
1. Crear un notebook nuevo.
2. Subir este archivo .py o copiar el contenido en una celda.
3. Ejecutar el código.
