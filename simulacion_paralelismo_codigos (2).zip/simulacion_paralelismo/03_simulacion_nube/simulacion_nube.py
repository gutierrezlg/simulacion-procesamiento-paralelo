import time
import multiprocessing as mp
from math import ceil

# -------------------------------------------------
# SIMULACIÓN SIMPLE DE PROCESAMIENTO EN LA NUBE
# -------------------------------------------------
# Idea:
# Cada "nodo" de la nube recibe una parte de los datos,
# procesa su bloque y luego devuelve un resultado parcial.
# Finalmente, el sistema central une todos los resultados.
#
# En este ejemplo simulamos registros de transacciones.
# Cada registro se revisa para contar cuántas transacciones
# superan cierto monto.
#
# Esto representa de forma sencilla cómo un sistema cloud
# distribuye carga entre varios nodos o workers.

def procesar_secuencial(transacciones, umbral):
    contador = 0
    for monto in transacciones:
        if monto > umbral:
            contador += 1
    return contador

def procesar_nodo(args):
    bloque, umbral, nodo_id = args
    contador = 0

    # Simula trabajo de un nodo cloud
    for monto in bloque:
        if monto > umbral:
            contador += 1

    print(f"Nodo {nodo_id} procesó {len(bloque)} registros y encontró {contador} transacciones mayores a {umbral}.")
    return contador

def dividir_en_bloques(lista, cantidad_nodos):
    tam_bloque = ceil(len(lista) / cantidad_nodos)
    return [lista[i:i + tam_bloque] for i in range(0, len(lista), tam_bloque)]

if __name__ == "__main__":
    # Datos simulados: transacciones de clientes
    transacciones = list(range(1, 5_000_001))
    umbral = 4_500_000

    print("===== SIMULACIÓN DE PROCESAMIENTO EN LA NUBE =====")
    print("Caso: análisis de transacciones distribuidas entre nodos cloud")
    print()

    # -------------------------
    # Procesamiento secuencial
    # -------------------------
    inicio_sec = time.time()
    resultado_sec = procesar_secuencial(transacciones, umbral)
    fin_sec = time.time()
    tiempo_sec = fin_sec - inicio_sec

    print("Modo secuencial:")
    print(f"Transacciones mayores a {umbral}: {resultado_sec}")
    print(f"Tiempo secuencial: {tiempo_sec:.4f} segundos")
    print()

    # -------------------------
    # Procesamiento distribuido
    # -------------------------
    nodos = mp.cpu_count()
    bloques = dividir_en_bloques(transacciones, nodos)
    tareas = [(bloques[i], umbral, i + 1) for i in range(len(bloques))]

    inicio_par = time.time()
    with mp.Pool(processes=nodos) as pool:
        resultados = pool.map(procesar_nodo, tareas)
    resultado_par = sum(resultados)
    fin_par = time.time()
    tiempo_par = fin_par - inicio_par

    print()
    print("Modo distribuido / nube:")
    print(f"Transacciones mayores a {umbral}: {resultado_par}")
    print(f"Tiempo distribuido: {tiempo_par:.4f} segundos")
    print()

    if tiempo_par > 0:
        print(f"Speedup: {tiempo_sec / tiempo_par:.4f}x")

    print()
    print("Interpretación:")
    print("- Cada nodo representa un recurso de cómputo en la nube.")
    print("- Los datos se dividen en bloques.")
    print("- Cada nodo procesa su parte en paralelo.")
    print("- Al final, se combinan los resultados parciales.")
